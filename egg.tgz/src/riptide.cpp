// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Model riptide flow"); }
int main(){
  announce();
  return lionss_run_workload("riptide");
}
