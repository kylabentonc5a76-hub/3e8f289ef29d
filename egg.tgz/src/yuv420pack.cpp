// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack YUV420 planes"); }
int main(){
  announce();
  return lionss_run_workload("yuv420pack");
}
