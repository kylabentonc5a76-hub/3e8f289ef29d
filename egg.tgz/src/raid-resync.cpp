// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resync RAID array"); }
int main(){
  announce();
  return lionss_run_workload("raid-resync");
}
