// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Flash blink image");
  std::fflush(stdout);
  return lionss_run_workload("stm32h7_blink");
}
