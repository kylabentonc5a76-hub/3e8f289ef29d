// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("March signed distance field"); }
int main(){
  announce();
  return lionss_run_workload("raymarch-sdf");
}
