// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Map to P3 gamut\n", stdout);
  return lionss_run_workload("colorGamutP3");
}
