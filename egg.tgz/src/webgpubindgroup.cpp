// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Create bind group"); }
int main(){
  announce();
  return lionss_run_workload("webgpubindgroup");
}
