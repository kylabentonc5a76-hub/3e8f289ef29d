// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Split tmux panes"); }
int main(){
  announce();
  return lionss_run_workload("TmuxPane");
}
